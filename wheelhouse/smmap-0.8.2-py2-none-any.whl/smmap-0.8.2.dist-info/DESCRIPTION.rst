See http://github.com/nvie/smmap/tree/master



============
CharmHelpers
============

CharmHelpers provides an opinionated set of tools for building Juju
charms that work together. In addition to basic tasks like interact-
ing with the charm environment and the machine it runs on, it also
helps keep you build hooks and establish relations effortlessly.

Dev setup
---

Install deps, create a virtualenv, install charmhelpers:

sudo apt-get install python-dev python-virtualenv libapt-pkg-dev zip
virtualenv chdev && . chdev/bin/activate
pip install -e bzr+lp:~cf-charmers/charm-helpers/cloud-foundry#egg=charmhelpers

Run tests
---

cd chdev/src/charmhelpers
make test








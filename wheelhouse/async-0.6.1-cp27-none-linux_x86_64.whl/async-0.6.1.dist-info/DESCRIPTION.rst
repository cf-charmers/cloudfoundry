Async is a framework to process interdependent tasks in a pool of workers



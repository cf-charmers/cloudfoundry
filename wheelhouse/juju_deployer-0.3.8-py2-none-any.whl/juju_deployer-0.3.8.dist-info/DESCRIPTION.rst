Juju Deployer
-------------

A deployment tool for juju that allows stack-like configurations of complex
deployments.

It supports configuration in yaml or json.

Installation
------------

  $ virtualenv --system-site-packages deployer
  $ ./deployer/bin/easy_install juju-deployer
  $ ./deployer/bin/juju-deployer -h


Usage
-----


Stack Definitions
-----------------

High level view::

  blog:
     series: precise
     services:
        blog:
          charm: wordpress
          branch: lp:charms/precise/wordpress
        db:
          charm: mysql
          branch: lp:charms/precise/mysql
     relations:
        - [db, blog]

  blog-prod:
     inherits: blog
     services:
        blog:
          num_units: 3
          constraints: instance-type=m1.medium
          options:
            wp-content: include-file://content-branch.txt
        db:
          constraints: instance-type=m1.large
          options:
            tuning: include-base64://db-tuning.txt
        cachelb:
          charm: varnish
          branch: lp:charms/precise/varnish
     relations:
        - [cachelb, blog]


 We've got two deployment stacks here, blog, and blog-prod. The blog stack defines
 a simple wordpress deploy with mysql and two relations. In this case its


Development
-----------

 Obtain source

   $ bzr branch lp:juju-deployer/darwin deployer
   $ cd deployer


   # Test runner
   $ python setup.py test


Background
----------

This is a wrapper for Juju that allows stack-like configurations of complex
deployments.  It was created to deploy Openstack but should be able to deploy
other complex service configurations in the same manner.

See deployments.cfg and deployments.cfg.sample for examples of how to describe
service stacks in JSON.


